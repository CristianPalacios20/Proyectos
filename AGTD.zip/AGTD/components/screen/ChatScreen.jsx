import { View, Text } from "react-native";

export default function ChatScreen({ route }) {
  const { chatId, userName, message } = route.params;

  return (
    <View style={{ flex: 1, padding: 20 }}>
      {/* Aquí se renderiza los mensajes según el chatId */}
      <Text>{userName}</Text>
      <Text>{message}</Text>
    </View>
  );
}
